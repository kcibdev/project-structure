class Endpoints {
  const Endpoints();
  String get baseUrl => 'http://localhost:3000';

  String get login => '/login';
  String get user => '/user';
}
