import 'package:flutter/material.dart';

void unfocus() => FocusManager.instance.primaryFocus?.unfocus();
